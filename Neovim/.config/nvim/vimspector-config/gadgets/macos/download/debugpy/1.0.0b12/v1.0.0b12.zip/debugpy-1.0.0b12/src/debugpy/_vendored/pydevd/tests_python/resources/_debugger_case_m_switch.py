from . import _debugger_case_m_switch_2
print(_debugger_case_m_switch_2.ClassToBeImported)
print('TEST SUCEEDED!')