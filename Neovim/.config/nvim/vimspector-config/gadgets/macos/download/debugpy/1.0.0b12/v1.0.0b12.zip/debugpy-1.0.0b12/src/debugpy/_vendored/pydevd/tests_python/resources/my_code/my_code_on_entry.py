print('my code on entry')
