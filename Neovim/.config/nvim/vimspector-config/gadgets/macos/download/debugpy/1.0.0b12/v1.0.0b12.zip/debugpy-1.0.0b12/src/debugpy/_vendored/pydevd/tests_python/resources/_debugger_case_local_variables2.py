

def Call():
    variable_for_test_1 = ['a', 'b']
    variable_for_test_2 = set(['a'])

    all_vars_set = True  # Break here


if __name__ == '__main__':
    Call()
    print('TEST SUCEEDED!')
