#!/bin/bash
set -ev

pip install pytest==4.4.2 untangle pathlib2
